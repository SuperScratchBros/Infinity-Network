# Modular Ultraviolet-Inspired Proxy

## File Structure
- `server.js`: Main entry point
- `utils/rewrite.js`: Handles rewriting of HTML and CSS
- `utils/ws-proxy.js`: WebSocket tunneling
- `public/index.html`: UI
- `public/style.css`: Styling
- `public/inject.js`: JS injection for event handling and WebSocket patching

## Features
- Spoof headers (User-Agent, Referer)
- Supports cookies and sessions
- DuckDuckGo fallback search
- Multiplayer game compatibility via WebSockets
- URL rewriting for HTML/CSS/JS

## Run Instructions
```bash
npm install express ws
node server.js
```

Visit `http://localhost:3000` or your Replit-hosted URL.